// Server configuration
const SERVER_URL = "https://ai-assistant-hub-app.azurewebsites.net";

// DOM elements
const userInfo = document.getElementById("user-info");
const userEmail = document.getElementById("user-email");
const usageInfo = document.getElementById("usage-info");
const authForm = document.getElementById("auth-form");
const emailInput = document.getElementById("email-input");
const passwordInput = document.getElementById("password-input");
const loginBtn = document.getElementById("login-btn");
const registerBtn = document.getElementById("register-btn");
const authToggle = document.getElementById("auth-toggle");
const messageContainer = document.getElementById("message-container");
const assistantToggle = document.getElementById("assistant-toggle");
const notificationsToggle = document.getElementById("notifications-toggle");
const supportSection = document.getElementById("support-section");
const supportBtn = document.getElementById("support-btn");

let isLoginMode = true;

// Load user status and show appropriate UI
async function loadUserStatus() {
  try {
    const token = await getAuthToken();

    if (!token) {
      // User not logged in - show login form
      showLoginForm();
      return;
    }

    // User is logged in - get user info
    const response = await fetch(`${SERVER_URL}/api/auth/me`, {
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
    });

    if (!response.ok) {
      throw new Error("Failed to get user info");
    }

    const data = await response.json();
    console.log("[Popup] Server response data:", data);

    const user = data.user;
    console.log("[Popup] User object:", user);

    // Show user info with subscription status
    showUserInfo(user);

    // Show support section for logged-in users
    if (supportSection) {
      supportSection.style.display = "block";
    }
  } catch (error) {
    console.error("Error loading user status:", error);
    showLoginForm();
  }
}

// Initialize popup
document.addEventListener("DOMContentLoaded", async () => {
  try {
    await loadUserStatus();
    await loadAssistantVisibility();
    setupEventListeners();
  } catch (error) {
    console.error("Error initializing popup:", error);
    // Show a fallback UI if initialization fails
  }
});

// Get authentication token from storage
async function getAuthToken() {
  try {
    const { token } = await chrome.storage.sync.get(["token"]);
    return token;
  } catch (error) {
    console.error("Error getting auth token:", error);
    return null;
  }
}

// Show login form
function showLoginForm() {
  if (userInfo) userInfo.classList.remove("show");
  if (authForm) authForm.classList.add("show");
  if (supportSection) supportSection.style.display = "none";
  updateAuthForm();
}

// Show authentication form
function showAuthForm() {
  userInfo.classList.remove("show");
  authForm.classList.add("show");
  supportSection.style.display = "none"; // Hide support section for non-logged-in users
}

// Update authentication form based on mode
function updateAuthForm() {
  if (!loginBtn || !registerBtn || !authToggle) return;

  if (isLoginMode) {
    loginBtn.style.display = "block";
    registerBtn.style.display = "block";
    authToggle.textContent = "Don't have an account? Register";
  } else {
    loginBtn.style.display = "none";
    registerBtn.style.display = "block";
    authToggle.textContent = "Already have an account? Login";
  }
}

// Load assistant visibility setting
async function loadAssistantVisibility() {
  const { assistant_visible = true, assistant_notifications = true } =
    await chrome.storage.sync.get([
      "assistant_visible",
      "assistant_notifications",
    ]);
  if (assistantToggle)
    assistantToggle.classList.toggle("active", assistant_visible);
  if (notificationsToggle)
    notificationsToggle.classList.toggle("active", assistant_notifications);
}

// Setup event listeners
function setupEventListeners() {
  if (loginBtn) loginBtn.addEventListener("click", handleLogin);
  if (registerBtn) registerBtn.addEventListener("click", handleRegister);
  if (authToggle) authToggle.addEventListener("click", toggleAuthMode);
  if (assistantToggle)
    assistantToggle.addEventListener("click", toggleAssistantVisibility);
  if (notificationsToggle)
    notificationsToggle.addEventListener("click", toggleNotifications);
  if (supportBtn) supportBtn.addEventListener("click", handleSupportRequest);

  // Logout button functionality
  const logoutBtn = document.getElementById("logout-btn");
  if (logoutBtn) {
    logoutBtn.addEventListener("click", logout);
  }

  // Resend verification button functionality
  const resendVerificationBtn = document.getElementById(
    "resend-verification-btn"
  );
  if (resendVerificationBtn) {
    resendVerificationBtn.addEventListener("click", resendVerificationEmail);
  }

  // Password toggle functionality
  const passwordToggle = document.getElementById("password-toggle");
  if (passwordToggle && passwordInput) {
    const eyeIcon = passwordToggle.querySelector(".eye-icon");
    const eyeSlashIcon = passwordToggle.querySelector(".eye-slash-icon");

    passwordToggle.addEventListener("click", () => {
      const type = passwordInput.type === "password" ? "text" : "password";
      passwordInput.type = type;

      if (type === "text") {
        if (eyeIcon) eyeIcon.style.display = "none";
        if (eyeSlashIcon) eyeSlashIcon.style.display = "block";
      } else {
        if (eyeIcon) eyeIcon.style.display = "block";
        if (eyeSlashIcon) eyeSlashIcon.style.display = "none";
      }
    });
  }

  // Enter key support
  if (emailInput) {
    emailInput.addEventListener("keypress", (e) => {
      if (e.key === "Enter") {
        if (isLoginMode) handleLogin();
        else handleRegister();
      }
    });
  }

  if (passwordInput) {
    passwordInput.addEventListener("keypress", (e) => {
      if (e.key === "Enter") {
        if (isLoginMode) handleLogin();
        else handleRegister();
      }
    });
  }
}

// Handle login
async function handleLogin() {
  const email = emailInput.value.trim();
  const password = passwordInput.value;

  if (!email || !password) {
    showMessage("Please fill in all fields", "error");
    return;
  }

  try {
    loginBtn.disabled = true;
    loginBtn.textContent = "Logging in...";

    console.log("[Popup] Attempting login for:", email);

    const response = await fetch(`${SERVER_URL}/api/auth/login`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ email, password }),
    });

    const data = await response.json();
    console.log("[Popup] Login response:", response.status, data);

    if (response.ok) {
      console.log("[Popup] Login successful, storing token...");
      await chrome.storage.sync.set({ token: data.token });

      // Verify token was stored
      const stored = await chrome.storage.sync.get(["token"]);
      console.log("[Popup] Token stored successfully:", !!stored.token);

      showMessage("Login successful!", "success");
      await loadUserStatus();

      // Notify content script about the new authentication state
      const [tab] = await chrome.tabs.query({
        active: true,
        currentWindow: true,
      });
      if (tab) {
        chrome.tabs.sendMessage(tab.id, {
          action: "authenticationStateChanged",
          hasToken: true,
        });
      }

      // If not verified, show verify message
      if (data.user && data.user.isEmailVerified === false) {
        showMessage(
          "Please verify your email to use the service. Check your inbox.",
          "error"
        );
      }
    } else {
      console.log("[Popup] Login failed:", data.error);
      showMessage(data.error || "Login failed", "error");
    }
  } catch (error) {
    console.error("[Popup] Login error:", error);
    showMessage("Connection error. Please try again.", "error");
  } finally {
    loginBtn.disabled = false;
    loginBtn.textContent = "Login";
  }
}

// Handle registration
async function handleRegister() {
  const email = emailInput.value.trim();
  const password = passwordInput.value;
  const username = email.split("@")[0]; // Use email prefix as username

  if (!email || !password) {
    showMessage("Please fill in all fields", "error");
    return;
  }

  if (password.length < 6) {
    showMessage("Password must be at least 6 characters", "error");
    return;
  }

  try {
    registerBtn.disabled = true;
    registerBtn.textContent = "Creating account...";

    const response = await fetch(`${SERVER_URL}/api/auth/register`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ email, password, username }),
    });

    const data = await response.json();

    if (response.ok) {
      await chrome.storage.sync.set({ token: data.token });
      showMessage(
        "Account created successfully! Please verify your email to use the service.",
        "success"
      );
      await loadUserStatus();

      // Notify content script about the new authentication state
      const [tab] = await chrome.tabs.query({
        active: true,
        currentWindow: true,
      });
      if (tab) {
        chrome.tabs.sendMessage(tab.id, {
          action: "authenticationStateChanged",
          hasToken: true,
        });
      }
    } else {
      showMessage(data.error || "Registration failed", "error");
    }
  } catch (error) {
    console.error("Registration error:", error);
    showMessage("Connection error. Please try again.", "error");
  } finally {
    registerBtn.disabled = false;
    registerBtn.textContent = "Create Account";
  }
}

// Toggle between login and register modes
function toggleAuthMode() {
  isLoginMode = !isLoginMode;
  updateAuthForm();
  clearMessage();
}

// Toggle assistant visibility
async function toggleAssistantVisibility() {
  const isActive = assistantToggle.classList.contains("active");
  const newState = !isActive;

  assistantToggle.classList.toggle("active", newState);
  await chrome.storage.sync.set({ assistant_visible: newState });

  // Notify content script about the change
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tab) {
    chrome.tabs.sendMessage(tab.id, {
      action: "assistantVisibilityChanged",
      visible: newState,
    });
  }
}

// Toggle notifications
async function toggleNotifications() {
  const isActive = notificationsToggle.classList.contains("active");
  const newState = !isActive;

  notificationsToggle.classList.toggle("active", newState);
  await chrome.storage.sync.set({ assistant_notifications: newState });

  // Notify content script about the change
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tab) {
    chrome.tabs.sendMessage(tab.id, {
      action: "notificationsChanged",
      enabled: newState,
    });
  }
}

// Toggle support section
async function toggleSupportSection() {
  supportSection.classList.toggle("show");
  await chrome.storage.sync.set({
    support_visible: supportSection.classList.contains("show"),
  });
}

// Show message
function showMessage(message, type) {
  clearMessage();

  const messageEl = document.createElement("div");
  messageEl.className = `${type}-message`;
  messageEl.textContent = message;
  messageContainer.appendChild(messageEl);

  // Auto-remove after 5 seconds
  setTimeout(() => {
    if (messageEl.parentNode) {
      messageEl.remove();
    }
  }, 5000);
}

// Clear message
function clearMessage() {
  messageContainer.innerHTML = "";
}

// Handle support request
async function handleSupportRequest() {
  try {
    const { token } = await chrome.storage.sync.get(["token"]);
    if (!token) {
      showMessage("Please log in to submit a support request.", "error");
      return;
    }

    // Get current tab to send message to content script
    const [tab] = await chrome.tabs.query({
      active: true,
      currentWindow: true,
    });

    if (tab) {
      // Send message to content script to show support form
      chrome.tabs.sendMessage(
        tab.id,
        { action: "showSupportForm" },
        (response) => {
          if (chrome.runtime.lastError) {
            // If content script is not available, show error
            showMessage("Please refresh the page and try again.", "error");
          }
        }
      );
    } else {
      showMessage("Please open a webpage and try again.", "error");
    }
  } catch (error) {
    console.error("Error handling support request:", error);
    showMessage("Error opening support form. Please try again.", "error");
  }
}

// Logout function (can be called from content script)
async function logout() {
  await chrome.storage.sync.remove(["token"]);
  showAuthForm();
  showMessage("Logged out successfully", "success");
}

// Expose logout function globally
window.logout = logout;

// Show user info with proper subscription status
function showUserInfo(user) {
  if (!userInfo) return;

  console.log("[Popup] showUserInfo called with user data:", user);

  // Check if user has usageStats property
  if (!user.usage) {
    console.error("[Popup] User object missing usageStats:", user);
    // Try to construct usageStats from user data
    user.usageStats = {
      requestsThisMonth: user.requestsThisMonth || 0,
      limit: user.limit || 10,
      remaining: user.remaining || 10,
      plan: user.plan || "free",
      status: user.status || "active",
    };
  }

  const { usageStats } = user;
  console.log("[Popup] Usage stats:", usageStats);

  // Update only the user info content, not the entire innerHTML
  const userEmail = userInfo.querySelector("#user-email");
  const usageInfo = userInfo.querySelector("#usage-info");

  if (userEmail) {
    userEmail.textContent = user.email;
  }

  if (usageInfo) {
    usageInfo.innerHTML = `
      <span class="usage-text">${user.usage.currentUsage || 0}/${
      user.usage.limit || 10
    } requests used (${user.usage.remaining || 10} remaining)</span>
      <div class="plan-info">
        <span class="plan-badge ${user.usage.plan || "free"}">${(
      user.usage.plan || "free"
    ).toUpperCase()}</span>
        <span class="status-badge ${user.usage.status || "active"}">${
      user.usage.status || "active"
    }</span>
      </div>
    `;
  }

  // Show upgrade button only for free users or users with inactive subscriptions
  const upgradeLink = document.getElementById("upgrade-link");
  if (upgradeLink) {
    if (
      (user.usage.plan || "free") === "free" ||
      (user.usage.status || "active") !== "active"
    ) {
      upgradeLink.style.display = "block";
      upgradeLink.href = "https://myassistanthub.com/#pricing";
      const upgradeBtn = upgradeLink.querySelector(".upgrade-btn");
      if (upgradeBtn) {
        upgradeBtn.innerHTML = `<i class="fas fa-crown"></i> ${
          (user.usage.plan || "free") === "free"
            ? "Upgrade to Pro"
            : "Renew Subscription"
        }`;
      }
    } else {
      upgradeLink.style.display = "none";
    }
  }

  // Show logout button
  const logoutBtn = document.getElementById("logout-btn");
  if (logoutBtn) {
    logoutBtn.style.display = "block";
  }

  // Show resend verification button for unverified users
  const resendVerificationBtn = document.getElementById(
    "resend-verification-btn"
  );
  if (resendVerificationBtn) {
    if (!user.isEmailVerified) {
      resendVerificationBtn.style.display = "block";
    } else {
      resendVerificationBtn.style.display = "none";
    }
  }

  // Hide auth form and show user info
  if (authForm) authForm.classList.remove("show");
  if (userInfo) userInfo.classList.add("show");
}

// Resend verification email
async function resendVerificationEmail() {
  try {
    const token = await getAuthToken();
    if (!token) {
      showMessage("Please log in first.", "error");
      return;
    }

    // Get user info to get email
    const response = await fetch(`${SERVER_URL}/api/auth/me`, {
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
    });

    if (!response.ok) {
      throw new Error("Failed to get user info");
    }

    const data = await response.json();
    const user = data.user;

    // Send resend verification request
    const resendResponse = await fetch(
      `${SERVER_URL}/api/auth/resend-verification`,
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          email: user.email,
        }),
      }
    );

    const resendData = await resendResponse.json();

    if (resendResponse.ok) {
      showMessage(
        "Verification email sent! Please check your inbox.",
        "success"
      );
    } else {
      showMessage(
        resendData.error || "Failed to send verification email.",
        "error"
      );
    }
  } catch (error) {
    console.error("Error resending verification email:", error);
    showMessage("Error sending verification email. Please try again.", "error");
  }
}
