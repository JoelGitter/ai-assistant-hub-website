const express = require('express');
const { body, validationResult } = require('express-validator');
const User = require('../models/User');
const Request = require('../models/Request');
const { auth } = require('../middleware/auth');
const { aiLimiter } = require('../middleware/rateLimit');
const OpenAIService = require('../services/openai');

const router = express.Router();

// Summarize page content
router.post('/summarize', auth, aiLimiter, [
  body('text').isString().notEmpty().isLength({ max: 10000 })
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ 
        error: 'Validation failed', 
        details: errors.array() 
      });
    }

    const { text } = req.body;
    const user = await User.findById(req.user._id);

    // Check if user can make requests
    if (!user.canMakeRequest()) {
      return res.status(403).json({
        error: 'Free tier limit reached. You have used all 10 free requests.',
        upgradeRequired: true,
        usage: user.usage
      });
    }

    // Call OpenAI service
    const result = await OpenAIService.summarizeText(text);

    if (!result.success) {
      // Log failed request
      await Request.create({
        userId: user._id,
        type: 'summarize',
        tokens: 0,
        cost: 0,
        status: result.status,
        errorMessage: result.error
      });

      return res.status(400).json({
        error: result.error,
        status: result.status
      });
    }

    // Increment user's request count
    await user.incrementRequestCount();

    // Log successful request
    await Request.create({
      userId: user._id,
      type: 'summarize',
      tokens: result.tokens,
      cost: result.cost,
      status: 'success',
      metadata: {
        url: req.body.url || null
      }
    });

    res.json({
      success: true,
      summary: result.summary,
      usage: {
        totalRequests: user.usage.totalRequests + 1,
        requestsRemaining: user.plan === 'pro' ? 'unlimited' : Math.max(0, 10 - (user.usage.totalRequests + 1))
      }
    });

  } catch (error) {
    console.error('Summarize error:', error);
    res.status(500).json({ 
      error: 'Server error during summarization' 
    });
  }
});

// Fill form field
router.post('/fill', auth, aiLimiter, [
  body('context').isString().notEmpty(),
  body('instruction').optional().isString(),
  body('formality').optional().isIn(['Professional', 'Casual', 'Friendly', 'Formal', 'Short', 'Medium', 'Long']),
  body('removeEmDash').optional().isBoolean()
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ 
        error: 'Validation failed', 
        details: errors.array() 
      });
    }

    const { context, instruction, formality = 'Medium', removeEmDash = false } = req.body;
    const user = await User.findById(req.user._id);

    // Check if user can make requests
    if (!user.canMakeRequest()) {
      return res.status(403).json({
        error: 'Free tier limit reached. You have used all 10 free requests.',
        upgradeRequired: true,
        usage: user.usage
      });
    }

    // Call OpenAI service
    const result = await OpenAIService.fillField(context, instruction, formality, removeEmDash);

    if (!result.success) {
      // Log failed request
      await Request.create({
        userId: user._id,
        type: 'fill',
        tokens: 0,
        cost: 0,
        status: result.status,
        errorMessage: result.error
      });

      return res.status(400).json({
        error: result.error,
        status: result.status
      });
    }

    // Increment user's request count
    await user.incrementRequestCount();

    // Log successful request
    await Request.create({
      userId: user._id,
      type: 'fill',
      tokens: result.tokens,
      cost: result.cost,
      status: 'success',
      metadata: {
        url: req.body.url || null,
        fieldType: req.body.fieldType || null,
        instruction: instruction || null,
        formality: formality
      }
    });

    res.json({
      success: true,
      result: result.result,
      usage: {
        totalRequests: user.usage.totalRequests + 1,
        requestsRemaining: user.plan === 'pro' ? 'unlimited' : Math.max(0, 10 - (user.usage.totalRequests + 1))
      }
    });

  } catch (error) {
    console.error('Fill error:', error);
    res.status(500).json({ 
      error: 'Server error during field filling' 
    });
  }
});

// Get user's request history
router.get('/history', auth, async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 20;
    const skip = (page - 1) * limit;

    const requests = await Request.find({ userId: req.user._id })
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limit)
      .select('-__v');

    const total = await Request.countDocuments({ userId: req.user._id });

    res.json({
      requests,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit)
      }
    });

  } catch (error) {
    console.error('Get history error:', error);
    res.status(500).json({ 
      error: 'Server error while fetching history' 
    });
  }
});

module.exports = router; 