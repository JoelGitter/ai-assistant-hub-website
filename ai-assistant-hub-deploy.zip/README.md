# AI Assistant Hub Server

A Node.js server for the AI Assistant Hub Chrome extension, providing authentication, AI services, and usage tracking.

## Features

- **User Authentication**: Email/password registration and login
- **AI Services**: Page summarization and form field filling using OpenAI
- **Usage Tracking**: Monitor user requests and implement rate limiting
- **Free Tier**: 10 free requests per user
- **MongoDB Integration**: User data and request history storage
- **Security**: JWT tokens, rate limiting, input validation

## Setup

### 1. Install Dependencies

```bash
cd server
npm install
```

### 2. Environment Variables

Create a `.env` file based on `env.example`:

```bash
cp env.example .env
```

Fill in your configuration:

```env
# Server Configuration
PORT=3000
NODE_ENV=development

# MongoDB Atlas
MONGODB_URI=mongodb+srv://username:password@cluster.mongodb.net/ai-assistant-hub?retryWrites=true&w=majority

# JWT Secret (generate a strong random string)
JWT_SECRET=your-super-secret-jwt-key-here

# OpenAI API
OPENAI_API_KEY=your-openai-api-key-here

# Session Secret (generate a strong random string)
SESSION_SECRET=your-session-secret-here
```

### 3. MongoDB Atlas Setup

1. Create a MongoDB Atlas cluster
2. Create a database named `ai-assistant-hub`
3. Get your connection string and add it to `.env`

### 4. Run the Server

**Development:**
```bash
npm run dev
```

**Production:**
```bash
npm start
```

## API Endpoints

### Authentication

- `POST /api/auth/register` - Register new user
- `POST /api/auth/login` - Login user
- `GET /api/auth/me` - Get current user profile
- `PUT /api/auth/me` - Update user profile
- `GET /api/auth/usage` - Get usage statistics

### AI Services

- `POST /api/ai/summarize` - Summarize page content
- `POST /api/ai/fill` - Fill form field
- `GET /api/ai/history` - Get request history

### Health Check

- `GET /health` - Server health status

## Database Schema

### Users Collection
```javascript
{
  _id: ObjectId,
  email: String,
  password: String (hashed),
  username: String,
  usage: {
    totalRequests: Number,
    requestsThisMonth: Number,
    lastRequestDate: Date
  },
  plan: 'free' | 'pro',
  isActive: Boolean,
  createdAt: Date,
  updatedAt: Date
}
```

### Requests Collection
```javascript
{
  _id: ObjectId,
  userId: ObjectId,
  type: 'summarize' | 'fill',
  tokens: Number,
  cost: Number,
  status: 'success' | 'error' | 'rate_limited',
  errorMessage: String,
  metadata: {
    url: String,
    fieldType: String,
    instruction: String,
    formality: String
  },
  createdAt: Date
}
```

## Deployment to Azure

### 1. Azure App Service

1. Create an Azure App Service
2. Choose Node.js runtime
3. Configure environment variables in Azure
4. Deploy using Azure CLI or GitHub Actions

### 2. Environment Variables in Azure

Set these in your Azure App Service Configuration:

- `MONGODB_URI`
- `JWT_SECRET`
- `OPENAI_API_KEY`
- `SESSION_SECRET`
- `NODE_ENV=production`

### 3. CORS Configuration

Update the CORS configuration in `server.js` for your production domain:

```javascript
app.use(cors({
  origin: [
    'chrome-extension://*',
    'https://your-production-domain.com'
  ],
  credentials: true
}));
```

## Security Features

- **JWT Authentication**: Secure token-based authentication
- **Password Hashing**: bcrypt for password security
- **Rate Limiting**: Prevents abuse
- **Input Validation**: Express-validator for request validation
- **Helmet**: Security headers
- **CORS**: Controlled cross-origin requests

## Rate Limits

- **General API**: 100 requests per 15 minutes per IP
- **AI Endpoints**: 10 requests per minute per IP
- **Authentication**: 5 attempts per 15 minutes per IP

## Usage Tracking

- Tracks total requests per user
- Monitors monthly usage
- Logs request costs and tokens
- Stores request metadata for analytics

## Next Steps

1. **Deploy to Azure** following the deployment guide
2. **Update the Chrome extension** to use the new API endpoints
3. **Add billing integration** when ready to monetize
4. **Implement Google OAuth** for easier sign-up
5. **Add admin dashboard** for user management

## Support

For issues or questions, check the logs or create an issue in the repository. 