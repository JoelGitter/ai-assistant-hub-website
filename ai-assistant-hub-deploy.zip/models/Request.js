const mongoose = require('mongoose');

const requestSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  type: {
    type: String,
    enum: ['summarize', 'fill'],
    required: true
  },
  tokens: {
    type: Number,
    required: true
  },
  cost: {
    type: Number,
    required: true
  },
  status: {
    type: String,
    enum: ['success', 'error', 'rate_limited'],
    default: 'success'
  },
  errorMessage: {
    type: String
  },
  metadata: {
    url: String,
    fieldType: String,
    instruction: String,
    formality: String
  }
}, {
  timestamps: true
});

// Index for efficient queries
requestSchema.index({ userId: 1, createdAt: -1 });
requestSchema.index({ type: 1, createdAt: -1 });

module.exports = mongoose.model('Request', requestSchema); 