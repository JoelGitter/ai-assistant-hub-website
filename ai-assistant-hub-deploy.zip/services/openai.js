const OpenAI = require('openai');

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

class OpenAIService {
  static async summarizeText(text) {
    try {
      // Limit text to 3000 characters to avoid token limits
      const limitedText = text.slice(0, 3000);
      
      const response = await openai.chat.completions.create({
        model: "gpt-3.5-turbo",
        messages: [
          {
            role: "system",
            content: "You are a helpful assistant that summarizes web page content. Provide exactly 5 of the most important points as a numbered list. Be concise but informative."
          },
          {
            role: "user",
            content: `Please summarize this content:\n\n${limitedText}`
          }
        ],
        max_tokens: 400,
        temperature: 0.5
      });

      const summary = response.choices[0].message.content;
      
      // Post-process the output
      let processedSummary = summary
        .replace(/^(\d+)\./gm, '<b>$1.</b>') // Bold numbers
        .replace(/\n/g, '<br>'); // Convert newlines to HTML

      return {
        success: true,
        summary: processedSummary,
        tokens: response.usage.total_tokens,
        cost: this.calculateCost(response.usage)
      };
    } catch (error) {
      console.error('OpenAI Summarize Error:', error);
      
      if (error.status === 429) {
        return {
          success: false,
          error: 'Rate limit exceeded. Please try again in a moment.',
          status: 'rate_limited'
        };
      }
      
      return {
        success: false,
        error: 'Failed to summarize content. Please try again.',
        status: 'error'
      };
    }
  }

  static async fillField(context, instruction, formality, removeEmDash) {
    try {
      const prompt = `You are an AI assistant helping to fill form fields. 

Context about the field: ${context}

${instruction ? `User instruction: ${instruction}` : ''}

Formality: ${formality}

Be specific, detailed, and creative. Provide a response that is advanced, nuanced, and context-rich. ${formality === 'Long' ? 'Make the answer longer and more elaborate, with extra detail.' : ''}

Provide only the text that should go in the field, nothing else.`;

      const response = await openai.chat.completions.create({
        model: "gpt-3.5-turbo",
        messages: [
          {
            role: "system",
            content: "You are a helpful AI assistant that fills form fields with appropriate content based on context and user instructions."
          },
          {
            role: "user",
            content: prompt
          }
        ],
        max_tokens: 250,
        temperature: 0.85
      });

      let result = response.choices[0].message.content.trim();
      
      // Remove em-dashes if requested
      if (removeEmDash) {
        result = result.replace(/—/g, '');
      }

      return {
        success: true,
        result: result,
        tokens: response.usage.total_tokens,
        cost: this.calculateCost(response.usage)
      };
    } catch (error) {
      console.error('OpenAI Fill Error:', error);
      
      if (error.status === 429) {
        return {
          success: false,
          error: 'Rate limit exceeded. Please try again in a moment.',
          status: 'rate_limited'
        };
      }
      
      return {
        success: false,
        error: 'Failed to fill field. Please try again.',
        status: 'error'
      };
    }
  }

  static calculateCost(usage) {
    // GPT-3.5-turbo pricing (approximate)
    const inputCostPer1k = 0.0015; // $0.0015 per 1K input tokens
    const outputCostPer1k = 0.002; // $0.002 per 1K output tokens
    
    const inputCost = (usage.prompt_tokens / 1000) * inputCostPer1k;
    const outputCost = (usage.completion_tokens / 1000) * outputCostPer1k;
    
    return inputCost + outputCost;
  }
}

module.exports = OpenAIService; 