#!/bin/bash

# Azure Deployment Script for AI Assistant Hub
echo "🚀 Starting Azure deployment..."

# Check if Azure CLI is installed
if ! command -v az &> /dev/null; then
    echo "❌ Azure CLI not found. Please install it first:"
    echo "   https://docs.microsoft.com/en-us/cli/azure/install-azure-cli"
    exit 1
fi

# Check if logged in to Azure
if ! az account show &> /dev/null; then
    echo "❌ Not logged in to Azure. Please run: az login"
    exit 1
fi

# Configuration
RESOURCE_GROUP="ai-assistant-hub-rg"
LOCATION="eastus"
APP_SERVICE_PLAN="ai-assistant-hub-plan"
WEB_APP_NAME="ai-assistant-hub-app"
MONGODB_NAME="ai-assistant-hub-mongo"

echo "📋 Configuration:"
echo "   Resource Group: $RESOURCE_GROUP"
echo "   Location: $LOCATION"
echo "   App Service Plan: $APP_SERVICE_PLAN"
echo "   Web App: $WEB_APP_NAME"
echo ""

# Create Resource Group
echo "🔧 Creating Resource Group..."
az group create --name $RESOURCE_GROUP --location $LOCATION

# Create App Service Plan
echo "🔧 Creating App Service Plan..."
az appservice plan create \
    --name $APP_SERVICE_PLAN \
    --resource-group $RESOURCE_GROUP \
    --sku B1 \
    --is-linux

# Create Web App
echo "🔧 Creating Web App..."
az webapp create \
    --name $WEB_APP_NAME \
    --resource-group $RESOURCE_GROUP \
    --plan $APP_SERVICE_PLAN \
    --runtime "NODE|18-lts"

# Configure environment variables
echo "🔧 Setting environment variables..."
az webapp config appsettings set \
    --name $WEB_APP_NAME \
    --resource-group $RESOURCE_GROUP \
    --settings \
    NODE_ENV=production \
    PORT=8080

echo "✅ Azure resources created successfully!"
echo ""
echo "📝 Next steps:"
echo "1. Set your environment variables:"
echo "   az webapp config appsettings set --name $WEB_APP_NAME --resource-group $RESOURCE_GROUP --settings MONGODB_URI='your-mongodb-uri'"
echo "   az webapp config appsettings set --name $WEB_APP_NAME --resource-group $RESOURCE_GROUP --settings JWT_SECRET='your-jwt-secret'"
echo "   az webapp config appsettings set --name $WEB_APP_NAME --resource-group $RESOURCE_GROUP --settings OPENAI_API_KEY='your-openai-key'"
echo "   az webapp config appsettings set --name $WEB_APP_NAME --resource-group $RESOURCE_GROUP --settings SESSION_SECRET='your-session-secret'"
echo ""
echo "2. Deploy your code:"
echo "   az webapp deployment source config-local-git --name $WEB_APP_NAME --resource-group $RESOURCE_GROUP"
echo ""
echo "3. Your app will be available at:"
echo "   https://$WEB_APP_NAME.azurewebsites.net" 