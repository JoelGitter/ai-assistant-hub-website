const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const userSchema = new mongoose.Schema({
  email: {
    type: String,
    required: true,
    unique: true,
    lowercase: true,
    trim: true
  },
  password: {
    type: String,
    required: function() {
      return !this.googleId; // Password only required if not using Google OAuth
    },
    minlength: 6
  },
  username: {
    type: String,
    required: true,
    unique: true,
    trim: true,
    minlength: 3,
    maxlength: 30
  },
  googleId: {
    type: String,
    sparse: true
  },
  googleEmail: {
    type: String,
    sparse: true
  },
  isEmailVerified: {
    type: Boolean,
    default: false
  },
  usage: {
    totalRequests: {
      type: Number,
      default: 0
    },
    requestsThisMonth: {
      type: Number,
      default: 0
    },
    lastRequestDate: {
      type: Date
    }
  },
  plan: {
    type: String,
    enum: ['free', 'pro'],
    default: 'free'
  },
  isActive: {
    type: Boolean,
    default: true
  }
}, {
  timestamps: true
});

// Hash password before saving
userSchema.pre('save', async function(next) {
  if (!this.isModified('password')) return next();
  
  try {
    const salt = await bcrypt.genSalt(10);
    this.password = await bcrypt.hash(this.password, salt);
    next();
  } catch (error) {
    next(error);
  }
});

// Compare password method
userSchema.methods.comparePassword = async function(candidatePassword) {
  return bcrypt.compare(candidatePassword, this.password);
};

// Check if user can make requests (free tier limit)
userSchema.methods.canMakeRequest = function() {
  if (this.plan === 'pro') return true;
  return this.usage.totalRequests < 10;
};

// Increment request count
userSchema.methods.incrementRequestCount = function() {
  this.usage.totalRequests += 1;
  this.usage.requestsThisMonth += 1;
  this.usage.lastRequestDate = new Date();
  return this.save();
};

// Reset monthly usage (call this monthly)
userSchema.methods.resetMonthlyUsage = function() {
  this.usage.requestsThisMonth = 0;
  return this.save();
};

module.exports = mongoose.model('User', userSchema); 